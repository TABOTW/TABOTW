package myboard.model.dao;

public class MyboardDao {

}
