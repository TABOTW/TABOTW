package myboard.model.service;

public class MyboardService {

}
